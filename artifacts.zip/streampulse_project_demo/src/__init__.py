"""StreamPulse ML package."""
